package src;

public enum CardType {
	Visa,
	Mastercard,
	Discovery,
	AmericanExpress,
}
