package src;

public enum PerformerType {
	Music,
	Comedy,
	Theater,
	Sports
}
