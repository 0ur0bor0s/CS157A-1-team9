Import this .sql file into mysql workbench
